class Producto():
    
    ##Atributos
    id:str
    nombre:str
    apellido:str
    edad:int
    password:str
    correo:str
    esAdmin:bool
    esStaff:bool
    contacto:str
    
    #Constructor
    def __init__(self, id, nombre, apellido, edad, password, correo, esAdmin, esStaff, contacto):
        self.id=id,
        self.nombre=nombre,
        self.apellido=apellido,
        self.edad=edad,
        self.password=password,
        self.correo=correo,
        self.esAdmin=esAdmin,
        self.esStaff=esStaff,
        self.contacto=contacto
        
    ##Getters
        
    def getId(self):
        return self.id
    def getNombre(self):
        return self.nombre
    def getApellido(self):
        return self.apellido
    def getEdad(self):
        return self.edad
    def getPassword(self):
        return self.password
    def getCorreo(self):
        return self.correo
    def getEsAdmin(self):
        return self.esAdmin
    def getEsStaff(self):
        return self.esStaff
    def getContacto(self):
        return self.contacto
    
    ##Setters
    def setId(self, id):
        self.id=id
        return self.id
    def setNombre(self, nombre):
        self.nombre=nombre
        return self.nombre
    def setApellido(self, apellido):
        self.apellido=apellido
        return apellido
    
    
    