from entidades import Categoria

class Producto():
    
    ##Atributos
    
    idProducto:str
    categoriaId:Categoria
    nombre:str
    descripcion:str
    marca:str
    activo:bool
    fechaCreacion:date()
    
    ##Constructor
    
    def __init__(self, idProducto, categoriaId, nombre, apellido, descripcion, marca, activo, fechaCreacion):
        self.idProducto=idProducto,
        self.categoriaId=categoriaId,
        self.nombre = nombre
        self.apellido=apellido,
        self.descripcion=descripcion,
        self.marca=marca,
        self.activo=activo,
        self.fechaCreacion=fechaCreacion
        
    ##Getters
    
    def getIdProducto(self):
        return self.idProducto
    def getCategoriaId(self):
        return self.categoriaId
    def getNombre(self):
        return self.nombre
    def getDescripcion(self):
        return self.descripcion
    def getMarca(self):
        return self.marca
    def getActivo(self):
        return self.activo
    def getFechaCreacion(self):
        return self.fechaCreacion
    
    ##Setters
    
    def setIdProducto(self, id):
        self.idProducto=id
        return self.idProducto
    def setCategoria(self, categoriaId):
        self.categoriaId=categoriaId
        return self.categoriaId
    def setNombre(self, nombre):
        self.nombre=nombre
        return self.nombre
    def setDescripcion(self, descripcion):
        self.descripcion=descripcion
        return self.descripcion
    def setMarca(self, marca):
        self.marca=marca
        return self.marca
    def setActivo(self, activo):
        self.activo=activo
        return self.activo
    def setFechaCreacion(self, fechaCreacion):
        self.fechaCreacion=fechaCreacion
        return self.fechaCreacion
    
        
        
        
    